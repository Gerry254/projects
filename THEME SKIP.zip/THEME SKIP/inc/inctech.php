
<head>
<!--
THE BEGINNING OF THE HEADERS\

The Admin account password is: Admin
The General account password is: Staff
The Restricted account password is: Staff2


HOVER
font-size:44px;
-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style>
 
html{
zoom: 75%;
font-family: Calibri ;

}
h1{
color:#28a745;
}
ph{
color:#dc3545;

}

b{
color:black;
font-size: 12px;
font-family: Calibri ;
}
ph{
color:#dc3545;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #34495E;
 
  
}

li {
  float: left;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
/*   background-color: #1ABB9C; */
li a:hover, .dropdown:hover .dropbtn {

}

li.dropdown {
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
  display: block;
}

.sidebar{
	float:left;
	min-width:70px;
}

#grad1 {
  
  background-color: #FFAAAA; /* height: 200px;For browsers that do not support gradients */
  
  background-image: linear-gradient(white, #9CC2CB); /* Standard syntax (must be last) */
}
</style>
<link rel="stylesheet" href="./css/bootstrapy.min.css">
    <script src="./css/custom.min.js.download" defer="defer"></script>
  
	<link type="text/css" rel="stylesheet" href="./css/Main.min.css">
  <link href="./css/custom.min.css" rel="stylesheet">
    <link href="./css/custom.min.css" rel="stylesheet">
	 <!--   Custom Theme Style 

  
  
  -->
	 <!-- Own Theme Style -->
    <link href="./css/own.css" rel="stylesheet">
	
	<!-- Bootstrap -->
    <link href="./css/ccopy.min.css" rel="stylesheet">
    
	

</head>
<body>
<?php
if($theme== 'white')
{
	echo '
	<ul style=" background-image: linear-gradient(white, #9AC2FF);"  >
  
	<li>
<a href="#"><img src="./inc/img/home.png" width="42" height="42" border="0"> </a>
 <p>	<b>Home</b>	</p>
  </li>	 
  <li >
<a href="#"><img src="./inc/img/vehicles.jpg" width="42" height="42" border="0"> </a>
   <p>	<b>Vehicles</b>	</p>
      	</li>
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/inventory.png" width="42" height="42" border="0"> </a>
    <p>	<b>Parts</b>	</p> <div class="dropdown-content">
				<a href="inventoryproduct.php">Stock</a>
	
    </div>
  </li>
  
  
  
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> <img src="./inc/img/users.png" width="42" height="42" border="0">  </a>
    <p>	<b>Users</b>	</p> <div class="dropdown-content">
     <a href="registration.php">Register New User</a>
				
				
				<a href="#">Add Mechanic</a>
				<a href="#">View Mechanics</a>
	
    </div>
  </li>
 
	 <li>
<a href="#"><img src="./inc/img/services.jpg" width="42" height="42" border="0"> </a>
	  <p>	<b>Services</b>	</p></li>
	  


<li>
</li>
	<li>
	
<a href="#"><img src="./inc/img/payroll.png" width="42" height="42" border="0"> </a>
	<p>	<b>Invoices</b>	</p>
							
	 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/contract.png" width="42" height="42" border="0">  </a>
    <p>	<b>Job Cards</b>	</p> <div class="dropdown-content">
     <a href="jobcards.php">Job Card</a>
                <a href="gatepass.php">Gate Pass</a>
    </div>
  </li>			
		<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/account.jpg" width="42" height="42" border="0"> </a>
	<p>	<b>Accounts</b>	</p>
    <div class="dropdown-content">
    <a href="#">Income</a>
              <a href="#">Expenses</a>
    </div>
  </li>		
		
				<li><a href="#"><i class="fa fa-tty image_icon"></i>Sales </a> </li>		
  </li>
  
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> Reports</a>
    <div class="dropdown-content">
      <a href="stockreport.php">Stock Report</a>
                <a href="#">Vehicle Report</a>
                <a href="#">Purchase Department</a>
				<a href="#"> Financials</a>
				
				<a href="recents.php">Recent Activities</a>
    </div>
  </li>
  
  
  
  	

  		<li>
<a href="#"><img src="./inc/img/search.png" width="42" height="42" border="0"> </a>
  </li>	
  

  <li>
  
  &nbsp;Logout  &nbsp; <?php  	echo $name;	 ?>
  
<a href="#"><img src="./inc/img/logout.png" width="42" height="42" border="0"> </a>
  </li>
  
   <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> <img src="./inc/img/users.png" width="42" height="42" border="0">  </a>
    <p>	<b>THEMES</b>	</p> <div class="dropdown-content">
     <a href="darktheme.php">DARK</a>
     <a href="whitetheme.php">LIGHT</a>
				
				
	
    </div>
  </li>
 
</ul>
	';
	
}
elseif($theme= 'dark') 
{
	
	echo '
	<ul style=" background-image: linear-gradient(#AAAAAA, #FFFFFF);"  >
  
	<li>
<a href="#"><img src="./inc/img/home.png" width="42" height="42" border="0"> </a>
 <p>	<b>Home</b>	</p>
  </li>	 
  <li >
<a href="#"><img src="./inc/img/vehicles.jpg" width="42" height="42" border="0"> </a>
   <p>	<b>Vehicles</b>	</p>
      	</li>
 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/inventory.png" width="42" height="42" border="0"> </a>
    <p>	<b>Parts</b>	</p> <div class="dropdown-content">
				<a href="inventoryproduct.php">Stock</a>
	
    </div>
  </li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> <img src="./inc/img/users.png" width="42" height="42" border="0">  </a>
    <p>	<b>Users</b>	</p> <div class="dropdown-content">
     <a href="registration.php">Register New User</a>
				
				
				<a href="#">Add Mechanic</a>
				<a href="#">View Mechanics</a>
	
    </div>
  </li>
 
	 <li>
<a href="#"><img src="./inc/img/services.jpg" width="42" height="42" border="0"> </a>
	  <p>	<b>Services</b>	</p></li>
	  


<li>
</li>
	<li>
	
<a href="#"><img src="./inc/img/payroll.png" width="42" height="42" border="0"> </a>
	<p>	<b>Invoices</b>	</p>
							
	 <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/contract.png" width="42" height="42" border="0">  </a>
    <p>	<b>Job Cards</b>	</p> <div class="dropdown-content">
     <a href="jobcards.php">Job Card</a>
                <a href="gatepass.php">Gate Pass</a>
    </div>
  </li>			
		<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"><img src="./inc/img/account.jpg" width="42" height="42" border="0"> </a>
	<p>	<b>Accounts</b>	</p>
    <div class="dropdown-content">
    <a href="#">Income</a>
              <a href="#">Expenses</a>
    </div>
  </li>		
		
				<li><a href="#"><i class="fa fa-tty image_icon"></i>Sales </a> </li>		
  </li>
  
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> Reports</a>
    <div class="dropdown-content">
      <a href="stockreport.php">Stock Report</a>
                <a href="#">Vehicle Report</a>
                <a href="#">Purchase Department</a>
				<a href="#"> Financials</a>
				
				<a href="recents.php">Recent Activities</a>
    </div>
  </li>
  
  
  
  	

  		<li>
<a href="#"><img src="./inc/img/search.png" width="42" height="42" border="0"> </a>
  </li>	
  

  <li>
  
  &nbsp;Logout  &nbsp; <?php  	echo $name;	 ?>
  
<a href="#"><img src="./inc/img/logout.png" width="42" height="42" border="0"> </a>
  </li>
  
<li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn"> <img src="./inc/img/users.png" width="42" height="42" border="0">  </a>
    <p>	<b>THEMES</b>	</p> <div class="dropdown-content">
     <a href="darktheme.php">DARK</a>
     <a href="whitetheme.php">LIGHT</a>
				
				
	
    </div>
  </li>
  
</ul>

	';
	
}

?>

	