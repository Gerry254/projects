-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2020 at 06:11 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nmrmbmi`
--

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `station` varchar(100) NOT NULL,
  `site` varchar(100) DEFAULT NULL,
  `theme` varchar(10) NOT NULL DEFAULT 'white'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `name`, `email`, `password`, `title`, `department`, `station`, `site`, `theme`) VALUES
(6, 'admin', 'admin@mydomain.com', 'loginlogin', 'ADMIN', 'RECORDS SYSTEM', 'HQ', 'admin.php', 'white');


CREATE TABLE `mechanics` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `indexno` int(5) NOT NULL,
  `job` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Available',
  `pay` varchar(20) NOT NULL,
  `vehicle` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mechanics`
--

INSERT INTO `mechanics` (`id`, `name`, `indexno`, `job`, `department`, `status`, `pay`, `vehicle`) VALUES
(1, 'MUSTAFA KARUA', 1, 'MANAGER', 'WORKSHOP', 'Booked', '9000', ' KCS 595H '),
(2, 'PASCAL ONYANGO', 2, 'SUPERVISOR', 'WORKSHOP', 'AVAILABLE', '7500', ''),
(3, 'THOMAS OTIENO', 3, 'Q.C', 'WORKSHOP', 'AVAILABLE', '7500', ''),
(4, 'RAMADHAN OMAR', 4, 'FOREMAN', 'WORKSHOP', 'Available', '7000', ''),
(5, 'ONDITI JOSEPH', 5, 'TECHNICIAN', 'Mercedes', 'Booked', '3000', ' KCS 595H '),
(7, 'KEVIN OMONDI', 6, 'TECHNICIAN', 'Mercedes', 'AVAILABLE', '1500', ''),
(8, 'OGOLA K.', 7, 'TECHNICIAN', 'BODY SHOP', 'AVAILABLE', '1500', ''),
(9, 'CHARLES OBONDO', 8, 'TECHNICIAN', 'MITSUBISHI', 'Booked', '2000', ' KCS 595H '),
(10, 'OBURA PETER', 9, 'TECHNICIAN', 'BODY SHOP', 'Booked', '7500', ' KCS 595H '),
(11, 'KENEDY WACHIRA', 10, 'TECHNICIAN', 'BODY SHOP', 'Booked', '1500', 'KBK 262L');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mechanics`
--
ALTER TABLE `mechanics`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mechanics`
--
ALTER TABLE `mechanics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- Indexes for dumped tables
--

--
-- Indexes for table `profiles`
--


ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
