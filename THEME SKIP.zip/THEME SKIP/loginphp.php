<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<?php
require('confis.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['email'])){
        // removes backslashes
	$email = stripslashes($_REQUEST['email']);
        //escapes special characters in a string
	$email = mysqli_real_escape_string($mysqli,$email);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($mysqli,$password);
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `profiles` WHERE email='$email'
and password='$password'";
	//$result = mysqli_query($mysqli,$query) or die(mysqli_error($mysqli));
	//while($res = mysqli_fetch_array($result)) {         
   // $title=   $res['title'];}

	$results = mysqli_query($mysqli,$query) or die(mysqli_error($mysqli));
		
			$rows = mysqli_num_rows($results);
        if($rows==1){
	    $_SESSION['email'] = $email;
            // Redirect user to index.php
	    header("Location: trials.php");
         }else{
	echo "<div class='form'>
<h3>email/password is incorrect.</h3>
<br/>Click here to <a href='loginphp.php'>Login</a></div>";
	}
    }else{
?>
<div class="form">
<h1>Log In</h1>
<form action="" method="post" name="login">
<input type="email" name="email" placeholder="email" required />
<input type="password" name="password" placeholder="Password" required />
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <a href='registrationphp.php'>Register Here</a></p>
</div>
<?php } ?>
</body>
</html>