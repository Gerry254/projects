
<?php
// including the database connection file
include_once("configtech.php");

include("authi.php");
$name= $_SESSION['username'] ;
//$id = $_GET['id'];
 
 $user_info = mysqli_query($mysqli, "SELECT * FROM profiles WHERE name='$name' ");
  while($res = mysqli_fetch_array($user_info)) { 
	$theme=$res['theme'];
	$id=$res['id'];
	
  }  
 
		$result = mysqli_query($mysqli, 
		"UPDATE profiles SET theme = 'dark' WHERE name='$name'  ");
        
       echo $name;
	   echo $id; 
	   
	   header("Location: technicians.php");
    ?>