<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="./css/style1.css" />

<style>
body{
	background:#eee;color:#34495E
}
</style>
</head>
<body>
<?php
require('confis.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($mysqli,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($mysqli,$password);
	//Checking is user existing in the database or not<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
        $query = "SELECT * FROM `profiles` WHERE name='$username'
and password='$password'";
	$result = mysqli_query($mysqli,$query) or die(mysqli_error($mysqli));
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
            // Redirect user to index.php
	    header("Location: technicians.php");
         }else{
	echo "<div class='form'>
<h3>Username/password is incorrect.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
	}
    }else{
?>
<div class="form" align="center" >

<br></br>

    <img src="./inc/img/parts1.jpg" class="img-responsive hidden-xs" height ="188" width="188">
<br></br>


<h1>Log In</h1>
<!--

<input type="text" name="username" placeholder="Username" required />
<input type="password" name="password" placeholder="Password" required />
<input name="submit" type="submit" value="Login" />

-->
</div>
<form action="" method="post" name="login">
	<input type="hidden" name="_token" value="WIr30pnocOkUxbPo3Lcg5dWqf1b3jw9ZtwUdXd1x">
							<div class="form-group" align="center" style="margin-top:20px; float:center; ">
							
							<div class="">
									<label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">USERNAME <label class="text-danger"></label></label>
									<div class="col-md-4 col-sm-4 col-xs-12">
										<input type="text" name="username" value="" placeholder="Enter Your Username" maxlength="20" class="form-control" >
									</div>
								</div>
								</div>
								<div class="form-group" align="center" style="margin-top:20px;  float:center;">
								
								<div class="">
									<label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">PASSWORD<label class="text-danger"> </label></label>
									<div class="col-md-4 col-sm-4 col-xs-12">
										<input type="password" name="password" value="" placeholder="Enter Your Password" maxlength="30" class="form-control" required="">
									</div>
									
									<input name="submit" type="submit" value="Login" />
								</form></div>
							<p>FORGOT PASSWORD?</p>
								
							</div>
<?php } ?>
</body>
</html>