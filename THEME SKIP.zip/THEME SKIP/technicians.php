<?php
require('configs.php');
include("authi.php");
$name= $_SESSION['username'] ;
//($pageno <= 1){ echo '#'; } else

 
	
	//echo"<h2>TYRES IN STOCK</h2>";
	//include 'reorder.php';
//echo"LOGGED IN AS  "; ECHO $_SESSION['username'];
	//echo "$_SESSION['username']";
	echo"<p>";
$result = mysqli_query($mysqli, "SELECT * FROM mechanics ORDER BY status ASC"); // using mysqli_query instead
//

$username=$_SESSION['username'];
?>
<!DOCTYPE html>
<!-- saved from url=(0053)http://pushnifty.com/dasinfoau/php/garage/vehicle/add ref --> 
<html dir="" lang="en" class=" ">


<?php

include( "./inc/headstech.html");

?>

    <table 
	 id="myTable"
class="table table-striped jambo_table dataTable no-footer dtr-inline" 
style=" width: 100%; font-color: #ffaaaa; " 
role="grid" aria-describedby="datatable_info"

	>
        <tr bgcolor='#CCCCCC'>
          <td><h4>Name </h4> </td>
            <td><h4>Index No</h4>    </td>
           <td><h4>Job</h4>     </td>
                <td><h4>Department</h4></td>
              <td><h4>Status</h4>  </td>
              <td> <h4> Vehicle</h4></td>
        </tr>
        <?php 
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array

//		" onClick=\"return confirm('Are you sure you want to delete?')\
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
			
			//echo"<a href=\'depotsendi.php?id=$res[id]\'>$res['name']</a>";<a href=\"editout.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a>
		// 	echo "<td><a href=\"depotsendi.php?id=$res[id]>".$res['name']."</a> </td>";        
        
			
           echo "<td>".$res['name']."</td>";
            echo "<td>".$res['indexno']."</td>";
            echo "<td>".$res['job']."</td>"; 
            echo "<td>".$res['department']."</td>";    
            echo "<td>".$res['status']."</td>";    
            echo "<td>".$res['vehicle']."</td>";    
             }
			 
			 
			 
        ?>
    </table>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>
<body>
<i class="fa fa-file-pdf-o"></i>
</body>
</html>